import React, { useEffect, useState } from 'react';
import './Feed.css'
import { Link } from 'react-router-dom';

const Feed = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://20.244.56.144/test/users', {
          headers: {
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiZXhwIjoxNzQyNjI0NzI2LCJpYXQiOjE3NDI2MjQ0MjYsImlzcyI6IkFmZm9yZG1lZCIsImp0aSI6IjE2NWJmMmUwLTNmMzItNDJiNC1hNTYzLTcxYWZiZGEwMzQ0MiIsInN1YiI6Im1lZW5ha3NoaS5rYW1ha29sYW51LjIyY3NlQGJtdS5lZHUuaW4ifSwiY29tcGFueU5hbWUiOiJBZmZvcmQiLCJjbGllbnRJRCI6IjE2NWJmMmUwLTNmMzItNDJiNC1hNTYzLTcxYWZiZGEwMzQ0MiIsImNsaWVudFNlY3JldCI6IlZLRkNndkRueHVrdWVDdXAiLCJvd25lck5hbWUiOiJNZWVuYWtzaGkiLCJvd25lckVtYWlsIjoibWVlbmFrc2hpLmthbWFrb2xhbnUuMjJjc2VAYm11LmVkdS5pbiIsInJvbGxObyI6IjIyMDM2OSJ9.0OZLG8151Cl18IXOAvgVNR1Pce_G_s3h0AH1SLCnN-A',
            'Content-Type': 'application/json',
          },
        });

        const data = await response.json();
        console.log("API Response:", data);

        if (data.users && typeof data.users === 'object') {
          // Convert object values to an array
          const usersArray = Object.values(data.users);
          setUsers(usersArray);
        } else {
          console.error("Unexpected data format", data);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
    const interval = setInterval(fetchUsers, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <h2>User List</h2>
      <ul>
        {users.map((user, index) => (
          <li key={index}>{user}</li>
        ))}
      </ul>
      <Link to={'/topusers'} />
    </div>
  );
};

export default Feed;
