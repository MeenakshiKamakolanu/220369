import './App.css'
import Feed from './components/Feed/Feed'
import TopUsers from './components/TopUsers/TopUsers'

function App() {

  return (
    <div>
      <Feed/>

      <p>top users</p>
      <TopUsers/>
    </div>
  )
}

export default App
